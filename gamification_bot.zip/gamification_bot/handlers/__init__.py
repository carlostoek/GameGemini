from . import user_handlers
from . import admin_handlers
# from . import game_handlers # Uncomment if you add game-specific handlers
